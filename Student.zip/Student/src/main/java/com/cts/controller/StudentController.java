package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Course;
import com.cts.model.Student;
import com.cts.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	private StudentService service;
	
	@GetMapping("/test")
	public String test(){
		return "fuck you too";
	}
	
	@GetMapping("/allStudents")
	public List<Student> allStudents(){
		List<Student> studentsList = service.retrieveAllStudents();
		return studentsList;
	}
	
	@GetMapping("/addStudent")
	public String addStudent(){
		boolean flag = service.addStudent();
		return "Done";
	}
	
	@GetMapping("/retrieveStudent")
	public Student retrieveStudent(){
		Student student = service.retrieveStudent("002");
		System.out.println(student);
		return student;
	}
	
	@GetMapping("/getAllCourses")
	public List<Course> getAllCourses(){
		
		return null;
	}

	@GetMapping("/removeStudent")
	public Student removeStudent(String studentId){
		Student student = service.removeStudent("002");
		return student;
	}

}

package com.cts.service;

import java.util.List;

import com.cts.model.Course;
import com.cts.model.Student;

public interface StudentService {

	public List<Student> retrieveAllStudents();
	public Student retrieveStudent(String studentId);
	public Student removeStudent(String studentId);
	public List<Course> retrieveAllCourses(String studentId);
	public Course retrieveCourse(String studentId, String courseId);
	public Course addCourse(String studentId, Course course);
	public boolean addStudent();
}

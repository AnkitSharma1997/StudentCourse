package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.StudentDao;
import com.cts.model.Course;
import com.cts.model.Student;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentDao  dao;

	public List<Student> retrieveAllStudents() {
		// TODO Auto-generated method stub
		return dao.retrieveAllStudents();
	}

	public Student retrieveStudent(String studentId) {
		// TODO Auto-generated method stub
		return dao.retrieveStudent(studentId);
	}

	public Student removeStudent(String studentId) {
		// TODO Auto-generated method stub
		return dao.removeStudent(studentId);
	}

	public List<Course> retrieveAllCourses(String studentId) {
		// TODO Auto-generated method stub
		
		return dao.retrieveAllCourses(studentId);
	}

	public Course retrieveCourse(String studentId, String courseId) {
		// TODO Auto-generated method stub
		return dao.retrieveCourse(studentId, courseId);
	}

	public Course addCourse(String studentId, Course course) {
		// TODO Auto-generated method stub
		return dao.addCourse(studentId, course);
	}

	public boolean addStudent(){
		return dao.addStudent();
	}

}

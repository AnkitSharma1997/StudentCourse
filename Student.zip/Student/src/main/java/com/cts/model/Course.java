package com.cts.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
	@Id
	private String courseId;
	@Column
	private String course;
	
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", course=" + course + "]";
	}
	public Course(String courseId, String course) {
		super();
		this.courseId = courseId;
		this.course = course;
	}
	public Course() {
		
	}

	
}

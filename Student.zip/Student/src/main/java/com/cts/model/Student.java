package com.cts.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Student {
	
	@Id
	private String studentId;
	@Column
	private String studentName;
	@Column
	private String discription;
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Course> courses;
	
	public void addCourse(Course course){
		if(courses==null){
			courses= new ArrayList<Course>();
		}
		courses.add(course);
		
	}
	
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", discription=" + discription
				+ "]";
	}

	public Student(String studentId, String studentName, String discription) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.discription = discription;
	}

	public Student() {
		
	}
	
	
	
}

package com.cts.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.model.Course;
import com.cts.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	private List<Student> students;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	
	public List<Student> retrieveAllStudents() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		//Transaction tx = session.beginTransaction();
		Query query = session.createQuery("from Student");
		List<Student> studentList = query.getResultList();
		sessionFactory.close();
		return studentList;
	}

	public Student retrieveStudent(String studentId) {
		// TODO Auto-generated method stub
		Student student;
		try{
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Student where studentId=:studentId");
		query.setParameter("studentId", studentId);
		student =  (Student) query.getSingleResult();
		session.close();
		}
		catch(Exception ex){
			System.out.println("Student not found!!!");
		}
		return student;
	}

	public Student removeStudent(String studentId) {
		// TODO Auto-generated method stub
//		for(int i=0; i<students.size(); i++){
//			
//			if((students.get(i)).getStudentId() == studentId){
//				return students.remove(i);
//			}
//		}
		Session session = sessionFactory.openSession();
		
		Student student = retrieveStudent(studentId);
		if(student!=null){
			Transaction tx = session.beginTransaction();
			session.delete(student);
			tx.commit();
			session.close();
			return student;
			}
		
		return null;
	}

	public List<Course> retrieveAllCourses(String studentId) {
		// TODO Auto-generated method stub
		
		for(int i=0; i<students.size(); i++){
			
			if(((students.get(i)).getStudentId()).equals(studentId)){
				
				return students.get(i).getCourses();
			}
		}
		
		return null;
	}

	public Course retrieveCourse(String studentId, String courseId) {
		// TODO Auto-generated method stub
		List<Course> courses;
		for(int i=0; i<students.size(); i++){
			
			if(((students.get(i)).getStudentId()).equals(studentId)){
				courses = students.get(i).getCourses();
				for(int j = 0; j<courses.size(); j++)
					if((courses.get(j).getCourseId()).equals(courseId))
						return courses.get(j);
				
			}
		}
		return null;
	}

	public Course addCourse(String studentId, Course course) {
		// TODO Auto-generated method stub
		List<Course> courses;
		for(int i=0; i<students.size(); i++){
			
			if(((students.get(i)).getStudentId()).equals(studentId)){
				courses = students.get(i).getCourses();
				courses.add(course);
			}
		}
		return null;
	}

	public boolean addStudent() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Course course1 = new Course("111", "spring");
		Course course2 = new Course("100", "python");
		Course course3 = new Course("102", "java");
		Course course4 = new Course("103", "mongodb");
		Course course5 = new Course("104", "Sql");
		
		
		Student student1 = new Student("002", "Ajay", "Emperor");
		student1.addCourse(course3);
		student1.addCourse(course4);
		student1.addCourse(course5);
//		students.add(student1);
		session.persist(student1);
		tx.commit();
		sessionFactory.close();
		return  true;
	}

}
